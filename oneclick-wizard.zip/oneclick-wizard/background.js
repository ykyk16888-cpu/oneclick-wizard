/**
 * background.js
 * 一鍵精靈 OneClick Wizard - Service Worker (Manifest V3)
 *
 * 負責：
 * 1. 點擊工具列圖示 -> 開啟／喚醒「管理視窗」
 * 2. 一鍵開啟：建立新視窗、依群組建立 Tab Group 並套用名稱/顏色
 * 3. 一鍵登出：清除 Cookie ＋ 網站資料，或依自訂登出網址/選擇器操作
 */

importScripts('storage.js');

var OCW_MANAGER_URL = 'manager.html';
var ocwManagerWindowId = null; // 追蹤目前開啟中的管理視窗 id

// -----------------------------------------------------------------------
// 0) 一次性自動填入標記管理
//    只有透過「一鍵開啟」建立的分頁，才會被標記為可自動填入帳密，
//    且每個分頁只能被消費（使用）一次，避免使用者自行瀏覽到同網址時
//    也被長駐在背景的邏輯自動套用帳號密碼。
// -----------------------------------------------------------------------
function ocwPendingKey(tabId) { return 'pending_autofill_' + tabId; }

async function ocwMarkTabForAutofill(tabId, siteId) {
  var obj = {};
  obj[ocwPendingKey(tabId)] = siteId;
  await chrome.storage.session.set(obj);
}

/** 讀取並「消耗」某分頁的自動填入標記，取用後立即移除，確保只會生效一次 */
async function ocwConsumeTabAutofill(tabId) {
  var key = ocwPendingKey(tabId);
  var result = await chrome.storage.session.get([key]);
  var siteId = result[key];
  if (siteId) {
    await chrome.storage.session.remove([key]);
  }
  return siteId || null;
}

chrome.tabs.onRemoved.addListener(function (tabId) {
  chrome.storage.session.remove([ocwPendingKey(tabId)]);
});

// -----------------------------------------------------------------------
// 0-1) 追蹤「網站 -> 目前分頁 id」，供一鍵登出時關閉分頁
//      Chrome 的分頁群組（Tab Group）沒有獨立的刪除 API，
//      而是「群組內最後一個分頁被關閉時，群組會自動消失」。
//      若登出時不關閉分頁，每次「一鍵開啟」都會建立全新的分頁與群組，
//      舊的分頁／群組留在畫面上不斷累積。因此登出時一併關閉對應分頁，
//      讓已清空的分頁群組可以自動被 Chrome 移除。
// -----------------------------------------------------------------------
var OCW_SITE_TAB_MAP_KEY = 'site_tab_map';

async function ocwGetSiteTab(siteId) {
  var result = await chrome.storage.session.get([OCW_SITE_TAB_MAP_KEY]);
  var map = result[OCW_SITE_TAB_MAP_KEY] || {};
  return typeof map[siteId] === 'number' ? map[siteId] : null;
}

async function ocwClearSiteTab(siteId) {
  var result = await chrome.storage.session.get([OCW_SITE_TAB_MAP_KEY]);
  var map = result[OCW_SITE_TAB_MAP_KEY] || {};
  delete map[siteId];
  var obj = {};
  obj[OCW_SITE_TAB_MAP_KEY] = map;
  await chrome.storage.session.set(obj);
}

/** 登出時嘗試關閉該網站目前追蹤到的分頁，讓對應的分頁群組能自然消失 */
async function ocwCloseTrackedTabForSite(siteId) {
  var tabId = await ocwGetSiteTab(siteId);
  if (tabId === null) return;
  try {
    await chrome.tabs.remove(tabId);
  } catch (e) {
    // 分頁可能已經被使用者手動關閉，忽略錯誤即可
  }
  await ocwClearSiteTab(siteId);
}

// -----------------------------------------------------------------------
// 1) 點擊工具列圖示 -> 開啟管理視窗
// -----------------------------------------------------------------------
chrome.action.onClicked.addListener(function () {
  openManagerWindow();
});

async function openManagerWindow() {
  // 若視窗仍存在就直接聚焦，避免開出多個管理視窗
  if (ocwManagerWindowId !== null) {
    try {
      var existing = await chrome.windows.get(ocwManagerWindowId);
      if (existing) {
        chrome.windows.update(ocwManagerWindowId, { focused: true });
        return;
      }
    } catch (e) {
      ocwManagerWindowId = null; // 視窗已關閉
    }
  }

  var data = await ocwGetData();
  var bounds = data.settings.windowBounds || {};
  var createOpts = {
    url: chrome.runtime.getURL(OCW_MANAGER_URL),
    type: 'popup',
    width: bounds.width || 1100,
    height: bounds.height || 720
  };
  if (typeof bounds.left === 'number' && typeof bounds.top === 'number') {
    createOpts.left = bounds.left;
    createOpts.top = bounds.top;
  }

  var win = await chrome.windows.create(createOpts);
  ocwManagerWindowId = win.id;
}

chrome.windows.onRemoved.addListener(function (windowId) {
  if (windowId === ocwManagerWindowId) {
    ocwManagerWindowId = null;
  }
});

// -----------------------------------------------------------------------
// 2) 訊息路由
// -----------------------------------------------------------------------
chrome.runtime.onMessage.addListener(function (message, sender, sendResponse) {
  if (!message || !message.type) return false;

  if (message.type === 'OCW_OPEN_MANAGER') {
    openManagerWindow().then(function () { sendResponse({ ok: true }); });
    return true;
  }

  if (message.type === 'OCW_OPEN_SITES') {
    openSites(message.siteIds).then(function (result) {
      sendResponse({ ok: true, result: result });
    }).catch(function (err) {
      sendResponse({ ok: false, error: String(err && err.message || err) });
    });
    return true;
  }

  if (message.type === 'OCW_LOGOUT_SITES') {
    logoutSites(message.siteIds).then(function (result) {
      sendResponse({ ok: true, result: result });
    }).catch(function (err) {
      sendResponse({ ok: false, error: String(err && err.message || err) });
    });
    return true;
  }

  if (message.type === 'OCW_REQUEST_AUTOFILL') {
    var tabId = sender && sender.tab && sender.tab.id;
    if (tabId === undefined || tabId === null) {
      sendResponse({ ok: true, credential: null });
      return true;
    }
    (async function () {
      try {
        var siteId = await ocwConsumeTabAutofill(tabId);
        if (!siteId) {
          sendResponse({ ok: true, credential: null });
          return;
        }
        var data = await ocwGetData();
        var site = data.sites.filter(function (s) { return s.id === siteId; })[0];
        if (!site) {
          sendResponse({ ok: true, credential: null });
          return;
        }
        sendResponse({
          ok: true,
          credential: ocwResolveCredential(site, data.settings),
          usernameSelector: site.usernameSelector || null,
          passwordSelector: site.passwordSelector || null
        });
      } catch (err) {
        sendResponse({ ok: false, error: String(err && err.message || err) });
      }
    })();
    return true;
  }

  return false;
});

// -----------------------------------------------------------------------
// 3) 一鍵開啟：建立視窗 + 分頁分組 + (由 content.js 自動填入帳密)
// -----------------------------------------------------------------------
async function openSites(siteIds) {
  var data = await ocwGetData();
  var idSet = {};
  siteIds.forEach(function (id) { idSet[id] = true; });
  // 依「群組順序 -> 群組內網站順序 -> 未分組網站順序」排序，
  // 確保分頁開啟的順序與管理介面上顯示（拖曳排序後）的順序一致
  var sites = ocwSortedSitesForDisplay(data).filter(function (s) { return idSet[s.id]; });
  if (sites.length === 0) return { openedTabs: 0, reusedTabs: 0 };

  // 先檢查每個網站是否已經有追蹤到、且分頁仍然存在 -> 直接切換過去，不再重複開新分頁與新群組
  // （這是造成分頁群組越開越多的根本原因：以前不管有沒有已開著的分頁，每次都會整批重新建立）
  var siteTabMap = (await chrome.storage.session.get([OCW_SITE_TAB_MAP_KEY]))[OCW_SITE_TAB_MAP_KEY] || {};
  var sitesToOpen = [];
  var reusedTabIds = [];
  for (var i = 0; i < sites.length; i++) {
    var site = sites[i];
    var trackedTabId = siteTabMap[site.id];
    var stillOpen = false;
    if (typeof trackedTabId === 'number') {
      try {
        await chrome.tabs.get(trackedTabId);
        stillOpen = true;
      } catch (e) {
        stillOpen = false; // 分頁已不存在
      }
    }
    if (stillOpen) {
      reusedTabIds.push(trackedTabId);
    } else {
      sitesToOpen.push(site);
    }
  }

  // 已經開著的分頁：直接切換過去（聚焦視窗＋分頁），不重複建立
  if (reusedTabIds.length) {
    try {
      var firstTab = await chrome.tabs.get(reusedTabIds[0]);
      await chrome.windows.update(firstTab.windowId, { focused: true });
      await chrome.tabs.update(firstTab.id, { active: true });
    } catch (e) {
      // 忽略切換失敗
    }
  }

  if (sitesToOpen.length === 0) {
    return { openedTabs: 0, reusedTabs: reusedTabIds.length };
  }

  // 依網站設定隨機挑選網址（若有備用網址，避免單一網站異常卡住整組流程）
  var urls = sitesToOpen.map(function (s) { return ocwPickUrlForSite(s); });

  // 建立新視窗，一次帶入所有網址（第一個網址會是 active tab）
  var win = await chrome.windows.create({ url: urls, focused: true });
  var tabs = win.tabs || [];

  // 依群組把 tabId 分類，並「一次性批次寫入」每個分頁對應的網站標記
  // （避免逐一 await 造成延遲，讓載入很快的分頁在標記寫入前就已經詢問過，導致自動填入被錯過）
  var groupMap = {}; // groupId -> [tabId,...]
  var pendingWrites = {};
  for (var j = 0; j < sitesToOpen.length; j++) {
    var openSite = sitesToOpen[j];
    var tab = tabs[j];
    if (!tab) continue;
    var gid = openSite.groupId || '__none__';
    if (!groupMap[gid]) groupMap[gid] = [];
    groupMap[gid].push(tab.id);
    pendingWrites[ocwPendingKey(tab.id)] = openSite.id;
    siteTabMap[openSite.id] = tab.id;
  }
  pendingWrites[OCW_SITE_TAB_MAP_KEY] = siteTabMap;
  await chrome.storage.session.set(pendingWrites);

  var groupsById = {};
  data.groups.forEach(function (g) { groupsById[g.id] = g; });

  for (var gidKey in groupMap) {
    if (gidKey === '__none__') continue; // 未分組網站保持獨立分頁
    var tabIds = groupMap[gidKey];
    var groupInfo = groupsById[gidKey];
    if (!tabIds.length) continue;
    try {
      var chromeGroupId = await chrome.tabs.group({ tabIds: tabIds, createProperties: { windowId: win.id } });
      if (groupInfo) {
        await chrome.tabGroups.update(chromeGroupId, {
          title: groupInfo.name || '未命名群組',
          color: groupInfo.color || 'grey'
        });
      }
    } catch (e) {
      // 分組失敗不中斷流程（例如只有 1 個分頁時仍可分組，但保守處理錯誤）
      console.warn('[一鍵精靈] Tab 分組失敗：', e);
    }
  }

  return { openedTabs: tabs.length, reusedTabs: reusedTabIds.length };
}

// -----------------------------------------------------------------------
// 4) 一鍵登出
//    針對「目前市面上常見的登出方式」，依序嘗試多種手段，盡量確保登出成功：
//    a) 使用者自訂的登出網址（可選附加選擇器點擊登出按鈕）
//    b) 若只設定了選擇器、沒有登出網址 -> 直接在該網站目前開啟的分頁點擊登出按鈕
//       （涵蓋「登出按鈕在已登入頁面裡」而非獨立登出網址的常見情況）
//    c) 常見 SSO / 單一登入服務（Google、Microsoft、Yahoo 等）的官方登出端點
//    d) 清除 Cookie 與網站資料（含 apex 網域，涵蓋子網域共用登入狀態的情況）
//    最後關閉該網站目前追蹤到的分頁，讓分頁群組能自然消失
// -----------------------------------------------------------------------

// 常見 SSO / 單一登入服務的官方登出端點，只要網站網域符合就會自動一併觸發
var OCW_BUILTIN_SSO_LOGOUT = [
  { pattern: /(^|\.)google\.com$/i, url: 'https://accounts.google.com/Logout' },
  { pattern: /(^|\.)(microsoftonline|office|outlook|live|sharepoint)\.com$/i, url: 'https://login.microsoftonline.com/common/oauth2/logout' },
  { pattern: /(^|\.)yahoo\.com$/i, url: 'https://login.yahoo.com/account/logout' }
];
function ocwGetBuiltinSsoLogoutUrl(hostname) {
  for (var i = 0; i < OCW_BUILTIN_SSO_LOGOUT.length; i++) {
    if (OCW_BUILTIN_SSO_LOGOUT[i].pattern.test(hostname)) return OCW_BUILTIN_SSO_LOGOUT[i].url;
  }
  return null;
}

/** 將多行的登出選擇器欄位解析成依序點擊的步驟陣列（每行一個 CSS 選擇器） */
function ocwParseSelectorSteps(raw) {
  if (!raw) return [];
  return raw.split('\n').map(function (s) { return s.trim(); }).filter(Boolean);
}

async function logoutSites(siteIds) {
  var data = await ocwGetData();
  var sites = data.sites.filter(function (s) { return siteIds.indexOf(s.id) !== -1; });
  var results = [];

  for (var i = 0; i < sites.length; i++) {
    var site = sites[i];
    var methodsUsed = [];
    try {
      if (site.logoutUrl) {
        // a) 使用者自訂登出網址（可依序點擊多個步驟，例如先開下拉選單再點登出）
        await ocwVisitUrlAndClick(site.logoutUrl, ocwParseSelectorSteps(site.logoutSelector), {});
        methodsUsed.push('自訂登出網址');
      } else if (site.logoutSelector) {
        // b) 沒有指定登出網址，直接在該網站目前開啟的分頁上依序點擊登出步驟
        //    （例如：先點開下拉選單觸發按鈕，再點擊選單裡才會出現的登出項目）
        var selectorSteps = ocwParseSelectorSteps(site.logoutSelector);
        var tabId = await ocwGetSiteTab(site.id);
        if (tabId !== null && selectorSteps.length) {
          try {
            await chrome.scripting.executeScript({
              target: { tabId: tabId },
              func: function (selectors) {
                return new Promise(function (resolve) {
                  var i = 0;
                  function step() {
                    if (i >= selectors.length) { resolve(true); return; }
                    var el = document.querySelector(selectors[i]);
                    if (el) el.click();
                    i++;
                    setTimeout(step, 500);
                  }
                  step();
                });
              },
              args: [selectorSteps]
            });
            methodsUsed.push('分頁上依序點擊登出步驟');
            // 給頁面一點時間處理登出請求（例如送出表單、導向登出完成頁）
            await new Promise(function (resolve) { setTimeout(resolve, 700); });
          } catch (e) {
            // 找不到分頁或注入失敗，忽略並退回下方的 Cookie 清除
          }
        }
      }

      // c) 常見 SSO 服務的官方登出端點，自動一併執行（非必要步驟，失敗不影響整體結果）
      var hostname = ocwGetHostname(site.url);
      var ssoUrl = ocwGetBuiltinSsoLogoutUrl(hostname);
      if (ssoUrl) {
        try {
          await ocwVisitUrlAndClick(ssoUrl, null, { timeoutMs: 6000, closeDelayMs: 400 });
          methodsUsed.push('SSO 官方登出端點');
        } catch (e) {
          // 非必要步驟，忽略錯誤
        }
      }

      // d) 一律執行 Cookie／網站資料清除作為保底
      await logoutViaCookieClear(site);
      methodsUsed.push('清除 Cookie／網站資料');

      // 關閉該網站目前追蹤到的分頁，讓已清空的分頁群組能自動被 Chrome 移除
      await ocwCloseTrackedTabForSite(site.id);

      results.push({ id: site.id, method: methodsUsed.join('、'), ok: true });
    } catch (e) {
      results.push({ id: site.id, method: 'error', ok: false, error: String(e && e.message || e) });
    }
  }
  return results;
}

/**
 * 開啟一個網址，等待載入完成後（可選）依序點擊多個選擇器步驟，再關閉分頁。
 * selectorSteps 為 CSS 選擇器陣列，會依序點擊（例如先開下拉選單，再點擊登出項目）。
 * 修正舊版的競態條件：若頁面在監聽器掛上前就已經是 complete 狀態，
 * 或頁面遲遲不會進入 complete 狀態，都會用保險機制避免卡住整個流程。
 */
function ocwVisitUrlAndClick(url, selectorSteps, options) {
  var timeoutMs = (options && options.timeoutMs) || 8000;
  var closeDelayMs = (options && options.closeDelayMs) || 800;
  var steps = Array.isArray(selectorSteps) ? selectorSteps.filter(Boolean) : [];

  return new Promise(function (resolve) {
    chrome.tabs.create({ url: url, active: false }, function (tab) {
      if (chrome.runtime.lastError || !tab) {
        resolve(false);
        return;
      }
      var tabId = tab.id;
      var settled = false;

      function finishUp() {
        if (settled) return;
        settled = true;
        chrome.tabs.onUpdated.removeListener(onUpdated);

        var afterInject = function () {
          setTimeout(function () {
            chrome.tabs.remove(tabId, function () { resolve(true); });
          }, closeDelayMs);
        };

        if (steps.length) {
          chrome.scripting.executeScript({
            target: { tabId: tabId },
            func: function (selectors) {
              return new Promise(function (resolve) {
                var i = 0;
                function step() {
                  if (i >= selectors.length) { resolve(true); return; }
                  var el = document.querySelector(selectors[i]);
                  if (el) el.click();
                  i++;
                  setTimeout(step, 500);
                }
                step();
              });
            },
            args: [steps]
          }).then(afterInject).catch(afterInject);
        } else {
          afterInject();
        }
      }

      function onUpdated(updatedTabId, changeInfo) {
        if (updatedTabId !== tabId || changeInfo.status !== 'complete') return;
        finishUp();
      }
      chrome.tabs.onUpdated.addListener(onUpdated);

      // 保險 1：立即檢查一次目前狀態，避免頁面在監聽器掛上前就已經是 complete 而永遠等不到事件
      chrome.tabs.get(tabId, function (currentTab) {
        if (chrome.runtime.lastError) return;
        if (currentTab && currentTab.status === 'complete') finishUp();
      });

      // 保險 2：逾時後強制繼續，避免某些頁面（持續載入追蹤器等資源）永遠不會進入 complete 狀態
      setTimeout(finishUp, timeoutMs);
    });
  });
}

/** 清除該網站主要網址與所有備用網址對應網域（含 apex 網域，涵蓋子網域共用登入狀態）的 Cookie 與網站資料 */
async function logoutViaCookieClear(site) {
  var allUrls = ocwGetAllUrlsForSite(site);
  if (!allUrls.length) throw new Error('無法解析網址：' + site.url);

  var origins = [];
  var domainCandidates = {};
  for (var u = 0; u < allUrls.length; u++) {
    var hostname = ocwGetHostname(allUrls[u]);
    if (!hostname) continue;
    domainCandidates[hostname] = true;
    domainCandidates[hostname.replace(/^www\./, '')] = true;
    domainCandidates[ocwGetApexDomain(hostname)] = true; // 涵蓋子網域共用的登入狀態

    try {
      origins.push(new URL(allUrls[u]).origin);
    } catch (e) {
      // 略過無法解析的網址
    }
  }

  var seen = {};
  var domainList = Object.keys(domainCandidates).filter(Boolean);
  for (var d = 0; d < domainList.length; d++) {
    var cookies = await chrome.cookies.getAll({ domain: domainList[d] });
    for (var i = 0; i < cookies.length; i++) {
      var c = cookies[i];
      var key = c.name + '|' + c.domain + '|' + c.path;
      if (seen[key]) continue;
      seen[key] = true;
      var protocol = c.secure ? 'https://' : 'http://';
      var cookieUrl = protocol + c.domain.replace(/^\./, '') + c.path;
      try {
        await chrome.cookies.remove({ url: cookieUrl, name: c.name });
      } catch (e) {
        // 忽略單一 cookie 清除失敗
      }
    }
  }

  // 使用 browsingData 進一步清除這些網站的 localStorage / IndexedDB 等資料
  if (origins.length) {
    try {
      await chrome.browsingData.remove(
        { origins: origins },
        { cookies: true, localStorage: true, indexedDB: true, cacheStorage: true, serviceWorkers: true }
      );
    } catch (e) {
      console.warn('[一鍵精靈] browsingData 清除失敗：', e);
    }
  }

  return true;
}
