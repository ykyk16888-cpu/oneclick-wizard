/**
 * content.js
 * 一鍵精靈 OneClick Wizard - 自動填入帳號密碼（一次性行為）
 *
 * 重要設計原則：
 * 這支腳本雖然會注入到每個網頁，但「不會」自行比對目前網址是否符合已設定的網站，
 * 也不會長駐重複執行帳密填入。真正的判斷交給 background.js：
 * 只有透過「一鍵開啟」建立的分頁，background 才會標記該分頁可以自動填入，
 * 且這個標記只能被「消費」一次（取用後立即失效）。
 *
 * 因此：使用者自行手動輸入網址、點擊連結、或原本就開著的分頁，
 * 即使網址與已設定的網站相符，也「不會」被自動填入帳密。
 */

(function () {
  var FILL_TIMEOUT_MS = 8000;   // 最多嘗試填入 8 秒
  var REQUEST_RETRIES = [150, 300, 600, 1000]; // 詢問失敗時的重試間隔（毫秒）
  var alreadyFilled = false;
  var nextStepAttempted = false; // 避免重複點擊「下一步」造成無限迴圈

  // 常見帳號欄位選擇器（依優先順序）
  var USERNAME_SELECTORS = [
    'input[autocomplete="username"]',
    'input[autocomplete="email"]',
    'input[type="email"]',
    'input[name="username" i]',
    'input[name="login" i]',
    'input[name*="email" i]',
    'input[name*="user" i]',
    'input[name*="account" i]',
    'input[name*="login" i]',
    'input[name*="uid" i]',
    'input[name*="uname" i]',
    'input[id="username" i]',
    'input[id="login" i]',
    'input[id*="email" i]',
    'input[id*="user" i]',
    'input[id*="account" i]',
    'input[id*="login" i]',
    'input[id*="uid" i]',
    'input[placeholder*="帳號" i]',
    'input[placeholder*="帳戶" i]',
    'input[placeholder*="使用者" i]',
    'input[placeholder*="用戶" i]',
    'input[placeholder*="信箱" i]',
    'input[placeholder*="email" i]',
    'input[placeholder*="username" i]',
    'input[placeholder*="account" i]',
    'input[type="text"]',
    'input[type="tel"]',
    'input:not([type])'
  ];

  var PASSWORD_SELECTORS = [
    'input[type="password"]'
  ];

  // 「下一步／繼續／登入」按鈕的常見文字，用來處理帳號、密碼分兩頁輸入的登入流程
  var NEXT_STEP_TEXT_PATTERN = /^(next|continue|sign in|log in|登入|登錄|登录|下一步|繼續|继续|確定|确定|送出|提交)$/i;

  function isFillableVisible(el) {
    return !!el && el.offsetParent !== null && !el.disabled && !el.readOnly;
  }

  function findFirstVisible(selectors) {
    for (var i = 0; i < selectors.length; i++) {
      var els = document.querySelectorAll(selectors[i]);
      for (var j = 0; j < els.length; j++) {
        if (isFillableVisible(els[j])) return els[j];
      }
    }
    return null;
  }

  /**
   * 找出帳號欄位。許多網站的帳號欄位沒有明確的 name/id/placeholder 關鍵字，
   * 因此在關鍵字比對找不到結果時，進一步以「與密碼欄位同一個表單內、
   * 第一個可見的文字型輸入框」作為合理猜測。
   */
  function findUsernameField(passwordEl) {
    var byKeyword = findFirstVisible(USERNAME_SELECTORS);
    if (byKeyword) return byKeyword;

    var scope = (passwordEl && passwordEl.form) ? passwordEl.form : document;
    var candidates = scope.querySelectorAll(
      'input[type="text"], input[type="email"], input[type="tel"], input:not([type])'
    );
    var visible = Array.prototype.filter.call(candidates, isFillableVisible);
    if (visible.length >= 1) return visible[0];

    return null;
  }

  /** 尋找「下一步／繼續／登入」之類的按鈕，用於帳號、密碼分頁輸入的登入流程 */
  function findNextStepButton() {
    var explicit = document.querySelector('button[type="submit"], input[type="submit"]');
    if (isFillableVisible(explicit)) return explicit;

    var candidates = document.querySelectorAll('button, input[type="button"], a[role="button"]');
    for (var i = 0; i < candidates.length; i++) {
      var el = candidates[i];
      if (!isFillableVisible(el)) continue;
      var text = (el.innerText || el.value || el.getAttribute('aria-label') || '').trim();
      if (NEXT_STEP_TEXT_PATTERN.test(text)) return el;
    }
    return null;
  }

  function setNativeValue(el, value) {
    var proto = Object.getPrototypeOf(el);
    var descriptor = Object.getOwnPropertyDescriptor(proto, 'value');
    if (descriptor && descriptor.set) {
      descriptor.set.call(el, value);
    } else {
      el.value = value;
    }
    el.dispatchEvent(new Event('input', { bubbles: true }));
    el.dispatchEvent(new Event('change', { bubbles: true }));
    el.dispatchEvent(new KeyboardEvent('keyup', { bubbles: true }));
    el.dispatchEvent(new Event('blur', { bubbles: true }));
  }

  /**
   * 嘗試填入帳密。回傳 true 表示「已完成」（不再需要繼續嘗試）。
   * 若網站設定了自訂帳號／密碼欄位選擇器（overrides），會優先且僅使用該選擇器，
   * 不會退回自動偵測，確保使用者手動指定的欄位一定準確命中。
   * 部分網站（例如 Google／Microsoft 風格）帳號與密碼是分兩個步驟輸入，
   * 若目前頁面只找得到帳號欄位、還沒出現密碼欄位，會在填完帳號後
   * 自動嘗試點擊「下一步」之類的按鈕，讓密碼欄位有機會出現在下一輪偵測中。
   */
  function tryFill(credential, overrides) {
    if (alreadyFilled) return true;

    var passEl;
    if (overrides && overrides.passwordSelector) {
      var elP = document.querySelector(overrides.passwordSelector);
      passEl = isFillableVisible(elP) ? elP : null;
    } else {
      passEl = findFirstVisible(PASSWORD_SELECTORS);
    }

    var userEl;
    if (overrides && overrides.usernameSelector) {
      var elU = document.querySelector(overrides.usernameSelector);
      userEl = isFillableVisible(elU) ? elU : null;
    } else {
      userEl = findUsernameField(passEl);
    }

    var filledUsername = false;
    var filledPassword = false;

    if (userEl && credential.username && userEl !== passEl) {
      setNativeValue(userEl, credential.username);
      filledUsername = true;
    }
    if (passEl && credential.password) {
      setNativeValue(passEl, credential.password);
      filledPassword = true;
    }

    // 密碼欄位已填入，視為登入表單已完成（帳號同頁或已於前一步驟填妥）
    if (filledPassword) {
      alreadyFilled = true;
      return true;
    }

    // 只填了帳號、頁面上還沒有密碼欄位 -> 可能是分步驟登入，嘗試推進到下一步
    // （若使用者已自訂密碼欄位選擇器，代表密碼欄位理應同頁存在，暫不觸發自動推進，避免誤點）
    if (filledUsername && !passEl && !nextStepAttempted && !(overrides && overrides.passwordSelector)) {
      nextStepAttempted = true;
      setTimeout(function () {
        var btn = findNextStepButton();
        if (btn) btn.click();
      }, 250);
    }

    return false;
  }

  function requestAutofillWithRetry(attemptIndex, onCredential) {
    chrome.runtime.sendMessage({ type: 'OCW_REQUEST_AUTOFILL' }, function (resp) {
      if (chrome.runtime.lastError) return; // 擴充功能情境失效（例如頁面卸載）時安靜忽略

      if (resp && resp.ok && resp.credential && (resp.credential.username || resp.credential.password)) {
        onCredential(resp.credential, {
          usernameSelector: resp.usernameSelector || null,
          passwordSelector: resp.passwordSelector || null
        });
        return;
      }

      // 尚未取得憑證：可能是這個分頁本來就沒有被標記，也可能是背景標記還沒寫入完成（極短暫的競態）
      // 在合理次數內重試，避免因為時間差而漏掉本該套用的帳密
      if (attemptIndex < REQUEST_RETRIES.length) {
        setTimeout(function () {
          requestAutofillWithRetry(attemptIndex + 1, onCredential);
        }, REQUEST_RETRIES[attemptIndex]);
      }
    });
  }

  // 只在最上層分頁詢問，避免頁面內每個 iframe 都各自請求
  if (window.top !== window) return;

  requestAutofillWithRetry(0, function (credential, overrides) {
    // 立即嘗試一次
    if (tryFill(credential, overrides)) return;

    // 持續觀察 DOM 變化，處理動態載入的登入表單（但仍只套用「這一次」取得的憑證）
    var observer = new MutationObserver(function () {
      if (tryFill(credential, overrides)) {
        observer.disconnect();
      }
    });
    observer.observe(document.documentElement, { childList: true, subtree: true });

    setTimeout(function () {
      observer.disconnect();
    }, FILL_TIMEOUT_MS);
  });
})();
